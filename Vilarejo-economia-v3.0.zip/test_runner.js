"use strict";

const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const EventosV3 = require("./eventos_v3.js");

const ROOT = __dirname;
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const scriptCode = fs.readFileSync(path.join(ROOT, "script.js"), "utf8");
const loadedScripts = [...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)].map((match) => match[1]);
const failures = [];
let passed = 0;

function report(name, ok, detail = "") {
  if (ok) {
    passed += 1;
    console.log(`  ✓ ${name}${detail ? `: ${detail}` : ""}`);
  } else {
    failures.push(name);
    console.error(`  ✗ ${name}${detail ? `: ${detail}` : ""}`);
  }
}

function makeElement(id) {
  return {
    id,
    innerHTML: "",
    textContent: "",
    value: "",
    disabled: false,
    onclick: null,
    oninput: null,
    onchange: null,
    dataset: {},
    style: {},
    classList: {
      add() {},
      remove() {},
      contains() { return false; },
      toggle() { return false; }
    },
    closest() { return null; },
    appendChild() {},
    removeChild() {},
    setAttribute() {},
    getAttribute() { return null; },
    querySelector(selector) { return makeElement(`${id}:${selector}`); },
    querySelectorAll() { return []; }
  };
}

function createSimulationContext() {
  const elements = new Map();
  const getElementById = (id) => {
    if (!elements.has(id)) elements.set(id, makeElement(id));
    return elements.get(id);
  };
  const document = {
    getElementById,
    querySelector: getElementById,
    querySelectorAll: () => [],
    createElement: (tag) => makeElement(tag),
    activeElement: null,
    body: getElementById("body"),
    documentElement: getElementById("html")
  };
  const window = { document, EventosV3 };
  const context = {
    window,
    document,
    console,
    Math,
    Date,
    JSON,
    Object,
    Array,
    Number,
    String,
    Boolean,
    Map,
    Set,
    Intl,
    RegExp,
    Error,
    parseInt,
    parseFloat,
    isNaN,
    isFinite,
    Infinity,
    NaN,
    setInterval: () => 1,
    clearInterval: () => {},
    setTimeout: () => 1,
    clearTimeout: () => {}
  };
  vm.createContext(context);
  vm.runInContext(scriptCode, context, { filename: "script.js", timeout: 30000 });
  return context;
}

console.log("\n=== VERIFICAÇÕES ESTRUTURAIS ===");
report("A página carrega script.js exatamente uma vez", loadedScripts.filter((src) => src === "script.js").length === 1);
report("O motor de eventos é carregado antes do motor econômico", loadedScripts.filter((src) => src === "eventos_v3.js").length === 1 && loadedScripts.indexOf("eventos_v3.js") < loadedScripts.indexOf("script.js"));
report("A página declara idioma português", /<html\s+lang=["']pt-BR["']/i.test(html));
report("O executor de testes não depende de jsdom", !/require\(["']jsdom["']\)/.test(fs.readFileSync(path.join(ROOT, "test_runner.js"), "utf8")));

console.log("\n=== SUÍTE INTERNA DO MOTOR ECONÔMICO ===");
let simulation;
try {
  simulation = createSimulationContext();
  const api = simulation.window.VilarejoTest;
  if (!api || typeof api.runStressTests !== "function") throw new Error("window.VilarejoTest não foi inicializado");

  const result = api.runStressTests();
  for (const item of result.results) {
    report(item.name, item.passed, item.passed ? "aprovado" : JSON.stringify(item.detail || item.error));
  }
  report(`Total da suíte interna (${result.passed}/${result.total})`, result.passed === result.total);

  console.log("\n=== SIMULAÇÃO INTEGRADA DE CONTROLE ===");
  api.reset();
  const sixMonths = api.simulateMonths(6, false);
  const sixOk = sixMonths.monthNumber === 6 && sixMonths.cashAudit.ok &&
    sixMonths.balanceSheets.audit.allPass && sixMonths.nationalAccounts.reconciliation.reconciled;
  report("Seis meses: caixa, SFC e três óticas do PIB", sixOk,
    `mês=${sixMonths.monthNumber}; diferença de caixa=${sixMonths.cashAudit.difference.toFixed(8)}`);

  api.reset();
  const natural = api.simulateMonths(120, false);
  const naturalOk = natural.monthNumber >= 12 && natural.monthNumber <= 120 &&
    (Boolean(natural.gameOver) || natural.monthNumber === 120) &&
    natural.cashAudit.ok && natural.balanceSheets.audit.allPass &&
    natural.nationalAccounts.reconciliation.reconciled;
  report("Até 120 meses naturais: paradas, auditoria patrimonial e reconciliação",
    naturalOk,
    `meses concluídos=${natural.monthNumber}; encerramento=${natural.gameOver || "horizonte de 120 meses"}`);

  api.reset();
  const longRun = api.simulateMonths(240, false);
  const longRunOk = longRun.monthNumber === 240 && !longRun.gameOver && longRun.cashAudit.ok &&
    longRun.balanceSheets.audit.allPass && longRun.nationalAccounts.reconciliation.reconciled &&
    longRun.eventMonth === 240;
  report("240 meses naturais: continuidade, caixa, SFC, PIB e eventos integrados", longRunOk,
    `meses=${longRun.monthNumber}; gameOver=${longRun.gameOver || "não"}; eventos=${longRun.eventMonth}; caixa=${longRun.cashAudit.difference.toExponential(2)}`);

  const seedSweep = [1, 7, 17, 23, 42, 77, 99, 123, 256, 512, 1024, 2026,
    31337, 65535, 8675309, 123456789, 314159, 271828, 999999, 20261101,
    20261231, 86753090, 13579, 24680];
  const seedFailures = [];
  for (const seed of seedSweep) {
    api.resetWithSeed(seed);
    const scenario = api.simulateMonths(240, false);
    const scenarioOk = scenario.monthNumber === 240 && !scenario.gameOver && scenario.cashAudit.ok &&
      scenario.balanceSheets.audit.allPass && scenario.nationalAccounts.reconciliation.reconciled &&
      scenario.eventMonth === 240;
    if (!scenarioOk) seedFailures.push({ seed, month: scenario.monthNumber, gameOver: scenario.gameOver });
  }
  report("Robustez: 24 sementes × 240 meses sem colapso ou divergência", seedFailures.length === 0,
    seedFailures.length ? JSON.stringify(seedFailures) : "5.760 meses-simulação aprovados; caixa, SFC, PIB e eventos íntegros");

  api.reset();
  const eventEngine = simulation.window.EventosV3;
  const eventRun = api.simulateMonths(18, false);
  report("Eventos acompanham o calendário econômico mês a mês", eventRun.eventMonth === 18,
    `motor econômico=${eventRun.monthNumber}; motor de eventos=${eventRun.eventMonth}`);

  api.reset();
  const stress120 = api.simulateMonths(120, true);
  const stress120Ok = stress120.monthNumber === 120 && stress120.cashAudit.ok &&
    stress120.balanceSheets.audit.allPass && stress120.nationalAccounts.reconciliation.reconciled;
  report("Stress test de 120 meses após fim de jogo: SFC, caixa e PIB", stress120Ok,
    `meses simulados=${stress120.monthNumber}; crédito total=${stress120.loans.toFixed(2)}; diferença de caixa=${stress120.cashAudit.difference.toExponential(2)}`);
} catch (error) {
  report("Inicialização e execução do motor econômico", false, error.stack || String(error));
}

console.log("\n=== MOTOR DE EVENTOS V3 (MÓDULO INTEGRADO) ===");
try {
  const stateA = EventosV3.novoEstado({ semente: 2026 });
  const stateB = EventosV3.novoEstado({ semente: 2026 });
  for (let month = 0; month < 120; month += 1) {
    EventosV3.processarMes(stateA, 2, { calcularEconomia: false });
    EventosV3.processarMes(stateB, 2, { calcularEconomia: false });
  }
  const saved = EventosV3.salvarEstado(stateA);
  const restored = EventosV3.carregarEstado(saved);
  const deterministic = EventosV3.salvarEstado(stateA) === EventosV3.salvarEstado(stateB);
  report("Eventos: 120 ciclos sem erro e estado numérico válido",
    stateA.mes === 120 && Number.isFinite(stateA.caixa) && Array.isArray(stateA.log));
  report("Eventos: execução determinística com a mesma semente", deterministic);
  report("Eventos: serialização e restauração preservam o estado",
    restored.mes === stateA.mes && restored.semente === stateA.semente &&
    restored.log.length === stateA.log.length && restored.ativos.length === stateA.ativos.length);
  report("Catálogo de eventos disponível", Array.isArray(EventosV3.EVENTOS) && EventosV3.EVENTOS.length > 0,
    `${EventosV3.EVENTOS.length} eventos cadastrados`);
} catch (error) {
  report("Execução do motor de eventos V3", false, error.stack || String(error));
}

console.log(`\nResultado: ${passed} verificações aprovadas; ${failures.length} reprovadas.`);
if (failures.length) {
  console.error("Falhas:", failures.join(" | "));
  process.exitCode = 1;
}
